#!/usr/bin/env Rscript

# Figure2_Gaussian.R
# Publication-style Figure 2 for the temperature/coexistence manuscript.
# Generic unimodal thermal responses represented by a piecewise Gaussian.
# Outputs are written to ./Figure2_outputs/ relative to the current working directory.

rm(list = ls())

out_dir <- file.path(getwd(), "Figure2_outputs")
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

make_pdf <- TRUE
make_png <- TRUE

piecewise_gaussian <- function(T, Topt, H = 1, sigma_minus, sigma_plus) {
  C <- numeric(length(T))
  left <- T <= Topt
  C[left] <- H * exp(-0.5 * ((T[left] - Topt) / sigma_minus)^2)
  C[!left] <- H * exp(-0.5 * ((T[!left] - Topt) / sigma_plus)^2)
  C
}

omega_positive_quadrant <- function(C1, C2, beta = 0.80) {
  eps <- .Machine$double.eps
  ratio <- C2 / pmax(C1, eps)
  a12 <- beta * ratio
  a21 <- beta / pmax(ratio, eps)
  argument <- (1 - a12 * a21) / sqrt((1 + a12^2) * (1 + a21^2))
  argument <- pmin(pmax(argument, 0), 1)
  (2 / pi) * asin(argument)
}

T <- seq(0, 40, length.out = 4001)
beta <- 0.80
H1 <- 1
H2 <- 1

sigma_left_minus <- 7.0
sigma_left_plus <- 2.6
sigma_right_minus <- 2.6
sigma_right_plus <- 7.0

panels <- data.frame(
  panel = c("a", "b", "c"),
  title = c("Shared optimum at 19\u00B0C",
            "Shared optimum at 25\u00B0C",
            "Different thermal optima"),
  subtitle = c("", "", "19\u00B0C and 25\u00B0C"),
  Topt1 = c(19, 25, 19),
  Topt2 = c(19, 25, 25),
  stringsAsFactors = FALSE
)

col_species1 <- rgb(0.000, 0.447, 0.741) # blue
col_species2 <- rgb(0.850, 0.325, 0.098) # orange
col_omega <- rgb(0.000, 0.620, 0.450)    # green
col_guides <- rgb(0.494, 0.184, 0.556)   # purple

axis_cex <- 1.35
label_cex <- 1.55
title_cex <- 1.45
legend_cex <- 1.05
line_main <- 2.8
line_dash <- 2.8
line_guide <- 1.9
line_peak <- 2.4
axis_lwd <- 1.4

format_axes <- function(xlab, ylab, ylim, xlim = c(0, 40), yaxs = "i") {
  plot.new()
  plot.window(xlim = xlim, ylim = ylim, xaxs = "i", yaxs = yaxs)
  axis(1, at = seq(0, 40, 10), cex.axis = axis_cex, lwd = axis_lwd,
       lwd.ticks = axis_lwd, tcl = -0.30)
  axis(2, cex.axis = axis_cex, lwd = axis_lwd,
       lwd.ticks = axis_lwd, tcl = -0.30, las = 1)
  box(bty = "l", lwd = axis_lwd)
  mtext(xlab, side = 1, line = 2.8, cex = label_cex)
  mtext(ylab, side = 2, line = 3.2, cex = label_cex)
}

add_optimum_lines <- function(Topt1, Topt2, same_optimum = FALSE) {
  if (same_optimum) {
    abline(v = Topt1, col = col_guides, lty = 3, lwd = line_guide)
  } else {
    abline(v = Topt1, col = col_guides, lty = 3, lwd = line_guide)
    abline(v = Topt2, col = col_guides, lty = 3, lwd = line_guide)
  }
}

plot_consumption_panel <- function(i, C1, C2, Topt1, Topt2) {
  same_optimum <- abs(Topt1 - Topt2) < 1e-9
  format_axes("Temperature (\u00B0C)", expression(C[i](T)), ylim = c(0, 1.08))
  lines(T, C1, col = col_species1, lwd = line_main)
  lines(T, C2, col = col_species2, lwd = line_dash, lty = 2)
  add_optimum_lines(Topt1, Topt2, same_optimum)

  title_text <- paste0(panels$panel[i], " ", panels$title[i])
  if (panels$subtitle[i] != "") {
    title(main = paste0(title_text, "\n(", panels$subtitle[i], ")"),
          line = 0.7, cex.main = title_cex, font.main = 2)
  } else {
    title(main = title_text, line = 1.1, cex.main = title_cex, font.main = 2)
  }

}

plot_omega_panel <- function(Omega, Topt1, Topt2) {
  same_optimum <- abs(Topt1 - Topt2) < 1e-9
  idx_peak <- which.max(Omega)
  Tpeak <- T[idx_peak]
  Opeak <- Omega[idx_peak]

  format_axes("Temperature (\u00B0C)", expression(Omega(T)), ylim = c(0, max(Omega) * 1.20))
  lines(T, Omega, col = col_omega, lwd = line_main)
  add_optimum_lines(Topt1, Topt2, same_optimum)
  abline(v = Tpeak, col = col_guides, lty = 2, lwd = line_peak)

  title(main = bquote("Peak " * Omega * "(T): " * .(format(round(Tpeak, 1), nsmall = 1)) * degree * C),
        line = 0.7, cex.main = title_cex * 0.95, font.main = 2, col.main = col_guides)

  invisible(c(Tpeak = Tpeak, Opeak = Opeak))
}

make_figure <- function(filename, device = c("pdf", "png")) {
  device <- match.arg(device)
  if (device == "pdf") {
    pdf(filename, width = 14.0, height = 8.6, pointsize = 18, useDingbats = FALSE)
  } else {
    png(filename, width = 4200, height = 2580, res = 300, pointsize = 18)
  }
  on.exit(dev.off(), add = TRUE)

  op <- par(no.readonly = TRUE)
  on.exit(par(op), add = TRUE)

  layout(matrix(1:6, nrow = 2, byrow = TRUE), heights = c(1, 1.04))
  par(oma = c(0.6, 0.4, 2.0, 0.4), mar = c(4.8, 5.4, 3.8, 1.2), family = "sans")

  peak_summary <- data.frame(
    panel = panels$panel,
    Topt1 = panels$Topt1,
    Topt2 = panels$Topt2,
    Tpeak = NA_real_,
    Omegapeak = NA_real_
  )

  C_list <- vector("list", nrow(panels))
  Omega_list <- vector("list", nrow(panels))

  for (i in seq_len(nrow(panels))) {
    C1 <- piecewise_gaussian(T, panels$Topt1[i], H1, sigma_left_minus, sigma_left_plus)
    C2 <- piecewise_gaussian(T, panels$Topt2[i], H2, sigma_right_minus, sigma_right_plus)
    Omega <- omega_positive_quadrant(C1, C2, beta)
    C_list[[i]] <- list(C1 = C1, C2 = C2)
    Omega_list[[i]] <- Omega
  }

  for (i in seq_len(nrow(panels))) {
    plot_consumption_panel(i, C_list[[i]]$C1, C_list[[i]]$C2,
                           panels$Topt1[i], panels$Topt2[i])
  }
  for (i in seq_len(nrow(panels))) {
    peak <- plot_omega_panel(Omega_list[[i]], panels$Topt1[i], panels$Topt2[i])
    peak_summary$Tpeak[i] <- peak["Tpeak"]
    peak_summary$Omegapeak[i] <- peak["Opeak"]
  }

  # Figure-wide legend placed in the outer margin to avoid overlap with curves.
  par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE, xpd = NA)
  plot.new()
  legend("top",
         legend = c("Species 1", "Species 2", expression(Omega(T)), "Thermal optimum", expression("Peak " * Omega(T))),
         col = c(col_species1, col_species2, col_omega, col_guides, col_guides),
         lty = c(1, 2, 1, 3, 2),
         lwd = c(line_main, line_dash, line_main, line_guide, line_peak),
         horiz = TRUE,
         bty = "n",
         cex = legend_cex,
         inset = 0.005,
         seg.len = 2.8)

  invisible(peak_summary)
}

pdf_file <- file.path(out_dir, "Figure2_submission.pdf")
png_file <- file.path(out_dir, "Figure2_submission.png")
summary_file <- file.path(out_dir, "Figure2_submission_peak_summary.csv")

peak_summary <- NULL
if (make_pdf) peak_summary <- make_figure(pdf_file, "pdf")
if (make_png) make_figure(png_file, "png")
if (!is.null(peak_summary)) write.csv(peak_summary, summary_file, row.names = FALSE)

cat("\nFigure 2 files written to:\n")
if (make_pdf) cat("  ", normalizePath(pdf_file), "\n", sep = "")
if (make_png) cat("  ", normalizePath(png_file), "\n", sep = "")
if (!is.null(peak_summary)) cat("  ", normalizePath(summary_file), "\n", sep = "")
cat("\nPeak summary:\n")
print(peak_summary)
