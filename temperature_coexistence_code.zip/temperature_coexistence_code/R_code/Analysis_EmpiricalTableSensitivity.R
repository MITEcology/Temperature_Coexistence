# Analysis_EmpiricalTableSensitivity.R
#
# Purpose:
#   Independent R check of the empirical Drosophila coexistence summaries and
#   the size-matched tropical downsampling analysis used in the revised manuscript.
#
# Required input files, either in the working directory, the script directory,
#   or a ./data subdirectory:
#   FruitFly_OptimalTemperature.mat
#   FruitFly_Coexistence_LowT_Thick.mat
#   FruitFly_Coexistence_HighT_Thick.mat
#
# Required R package:
#   R.matlab
#
# Coding convention:
#   2   = coexistence
#   0   = non-coexistence
#   NaN = missing/inapplicable and excluded
#
# Outputs created in ./analysis_outputs/empirical_table_sensitivity_R:
#   Table_S2_empirical_pairclass_counts.csv
#   Table_S2_empirical_pairclass_counts.tex
#   Table_S3_tropical_downsampling_summary.csv
#   Table_S3_tropical_downsampling_summary.tex
#   tropical_downsampling_subsets.csv
#   empirical_table_sensitivity_report.txt

rm(list = ls())

if (!requireNamespace("R.matlab", quietly = TRUE)) {
  stop("Package 'R.matlab' is required. Install it with install.packages('R.matlab').")
}

# -----------------------------------------------------------------------------
# Paths
# -----------------------------------------------------------------------------

get_script_dir <- function() {
  cmd <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", cmd, value = TRUE)
  if (length(file_arg) > 0) {
    return(dirname(normalizePath(sub("^--file=", "", file_arg[1]), mustWork = FALSE)))
  }
  ofile <- tryCatch(sys.frames()[[1]]$ofile, error = function(e) NULL)
  if (!is.null(ofile)) {
    return(dirname(normalizePath(ofile, mustWork = FALSE)))
  }
  getwd()
}

script_dir <- get_script_dir()
out_dir <- file.path(getwd(), "analysis_outputs", "empirical_table_sensitivity_R")
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

find_input_file <- function(filename) {
  candidate_dirs <- unique(c(
    getwd(),
    script_dir,
    file.path(getwd(), "data"),
    file.path(script_dir, "data"),
    file.path(dirname(script_dir), "data")
  ))
  candidate_paths <- file.path(candidate_dirs, filename)
  hit <- candidate_paths[file.exists(candidate_paths)]
  if (length(hit) == 0) {
    stop(
      "Required input file not found: ", filename, "\n",
      "Looked in:\n  ", paste(candidate_dirs, collapse = "\n  "), "\n",
      "Place the file in the working directory, script directory, or a ./data subdirectory."
    )
  }
  hit[1]
}

# -----------------------------------------------------------------------------
# Helper functions robust to R.matlab field-name conversion
# -----------------------------------------------------------------------------

normalize_key <- function(z) tolower(gsub("[^A-Za-z0-9]", "", z))

get_field <- function(x, choices) {
  nms <- names(x)
  for (choice in choices) {
    if (choice %in% nms) return(x[[choice]])
  }
  nms_norm <- normalize_key(nms)
  for (choice in choices) {
    hit <- which(nms_norm == normalize_key(choice))
    if (length(hit) > 0) return(x[[hit[1]]])
  }
  stop(
    "Could not find any of these fields: ", paste(choices, collapse = ", "), "\n",
    "Available fields: ", paste(nms, collapse = ", ")
  )
}

string_one <- function(z) {
  if (is.null(z)) return(NA_character_)
  if (is.list(z)) {
    zz <- unlist(z, recursive = TRUE, use.names = FALSE)
  } else {
    zz <- as.vector(z)
  }
  if (length(zz) == 0) return(NA_character_)
  paste(as.character(zz), collapse = "")
}

to_character_vector <- function(x) {
  if (is.factor(x)) x <- as.character(x)
  if (is.character(x) && is.null(dim(x))) return(trimws(x))
  if (is.list(x)) return(trimws(vapply(x, string_one, character(1))))
  if (is.array(x) || is.matrix(x)) {
    # Character arrays returned by R.matlab can have dimensions. If each element
    # is already a string, flatten. If it is a character matrix, paste rows.
    if (is.character(x)) {
      if (length(dim(x)) == 2 && nchar(x[1]) == 1 && ncol(x) > 1) {
        return(trimws(apply(x, 1, paste, collapse = "")))
      }
      return(trimws(as.character(as.vector(x))))
    }
  }
  trimws(as.character(as.vector(x)))
}

to_numeric_matrix <- function(x) {
  x <- as.matrix(x)
  storage.mode(x) <- "numeric"
  x
}

read_fly_data <- function() {
  opt_path <- find_input_file("FruitFly_OptimalTemperature.mat")
  low_path <- find_input_file("FruitFly_Coexistence_LowT_Thick.mat")
  high_path <- find_input_file("FruitFly_Coexistence_HighT_Thick.mat")

  opt <- R.matlab::readMat(opt_path)
  low <- R.matlab::readMat(low_path)
  high <- R.matlab::readMat(high_path)

  list(
    opt_names = to_character_vector(get_field(opt, c("Name"))),
    opt_labels = to_character_vector(get_field(opt, c("Temperature_des", "Temperature.des", "TemperatureDes"))),
    low_names = to_character_vector(get_field(low, c("Name"))),
    high_names = to_character_vector(get_field(high, c("Name"))),
    A_low = to_numeric_matrix(get_field(low, c("A"))),
    A_high = to_numeric_matrix(get_field(high, c("A"))),
    opt_path = opt_path,
    low_path = low_path,
    high_path = high_path
  )
}

match_names <- function(source_names, target_names) {
  source_clean <- trimws(source_names)
  target_clean <- trimws(target_names)
  idx <- match(target_clean, source_clean)
  if (any(is.na(idx))) {
    stop("Could not match names: ", paste(target_names[is.na(idx)], collapse = ", "))
  }
  idx
}

check_codes <- function(A, label) {
  vals <- sort(unique(as.vector(A[!is.na(A)])))
  unexpected <- setdiff(vals, c(0, 2))
  if (length(unexpected) > 0) {
    warning(label, " contains values other than 0, 2, or NaN: ", paste(unexpected, collapse = ", "))
  }
}

count_ordered_within <- function(A, idx) {
  B <- A[idx, idx, drop = FALSE]
  diag(B) <- NA_real_
  valid <- !is.na(B)
  coex <- B == 2
  data.frame(
    coexistence = sum(coex, na.rm = TRUE),
    total = sum(valid),
    proportion = sum(coex, na.rm = TRUE) / sum(valid)
  )
}

count_rectangular <- function(A, row_idx, col_idx) {
  B <- A[row_idx, col_idx, drop = FALSE]
  valid <- !is.na(B)
  coex <- B == 2
  data.frame(
    coexistence = sum(coex, na.rm = TRUE),
    total = sum(valid),
    proportion = sum(coex, na.rm = TRUE) / sum(valid)
  )
}

latex_escape <- function(x) {
  x <- gsub("_", "\\\\_", x, fixed = TRUE)
  x
}

write_counts_tex <- function(counts, file) {
  latex_newline <- "\\\\"
  rows <- c(
    "\\begin{tabular}{lccc}",
    "\\hline",
    paste0("Pair class & 19$^\\circ$C & 25$^\\circ$C & Direction ", latex_newline),
    "\\hline"
  )
  wide_classes <- unique(counts$pair_class)
  display <- c(
    temperate_temperate = "Temperate--temperate",
    tropical_tropical = "Tropical--tropical",
    mixed_temperate_tropical = "Mixed temperate--tropical"
  )
  for (pc in wide_classes) {
    sub <- counts[counts$pair_class == pc, ]
    x19 <- sub[sub$temperature == "19C", ]
    x25 <- sub[sub$temperature == "25C", ]
    dir <- ifelse(x19$proportion > x25$proportion, "higher at 19$^\\circ$C",
                  ifelse(x19$proportion < x25$proportion, "higher at 25$^\\circ$C", "equal"))
    rows <- c(rows, paste0(
      sprintf("%s & %d/%d & %d/%d & %s ",
              display[[pc]], x19$coexistence, x19$total,
              x25$coexistence, x25$total, dir),
      latex_newline
    ))
  }
  rows <- c(rows, "\\hline", "\\end{tabular}")
  writeLines(rows, file)
}

write_downsampling_tex <- function(downsample_summary, file) {
  latex_newline <- "\\\\"
  rows <- c(
    "\\begin{tabular}{lc}",
    "\\hline",
    paste0("Quantity & Value ", latex_newline),
    "\\hline",
    paste0(sprintf("Temperate species & %d ", downsample_summary$n_temperate_species), latex_newline),
    paste0(sprintf("Tropical species & %d ", downsample_summary$n_tropical_species), latex_newline),
    paste0(sprintf("Tropical subsets sampled & %d ", downsample_summary$n_tropical_subsets), latex_newline),
    paste0(sprintf("Subsets with mixed pairs higher at 19$^\\circ$C than 25$^\\circ$C & %.1f\\%% ", downsample_summary$pct_mixed_19C_gt_25C), latex_newline),
    paste0(sprintf("Subsets with tropical pairs at least as high at 25$^\\circ$C as 19$^\\circ$C & %.1f\\%% ", downsample_summary$pct_tropical_25C_ge_19C), latex_newline),
    paste0(sprintf("Subsets with tropical pairs higher at 25$^\\circ$C than 19$^\\circ$C & %.1f\\%% ", downsample_summary$pct_tropical_25C_gt_19C), latex_newline),
    "\\hline",
    "\\end{tabular}"
  )
  writeLines(rows, file)
}

# -----------------------------------------------------------------------------
# Read data and define groups
# -----------------------------------------------------------------------------

dat <- read_fly_data()
check_codes(dat$A_low, "Low-temperature matrix")
check_codes(dat$A_high, "High-temperature matrix")

is_temperate <- dat$opt_labels == "TE"
is_tropical <- dat$opt_labels == "TR"

if (sum(is_temperate) == 0 || sum(is_tropical) == 0) {
  stop("Could not identify TE/TR groups from Temperature_des labels. Labels found: ",
       paste(sort(unique(dat$opt_labels)), collapse = ", "))
}

temperate_names <- dat$opt_names[is_temperate]
tropical_names <- dat$opt_names[is_tropical]

low_te_idx <- match_names(dat$low_names, temperate_names)
low_tr_idx <- match_names(dat$low_names, tropical_names)
high_te_idx <- match_names(dat$high_names, temperate_names)
high_tr_idx <- match_names(dat$high_names, tropical_names)

# -----------------------------------------------------------------------------
# Pair-class counts reported in the manuscript: Supplementary Table S2
# -----------------------------------------------------------------------------

te_low <- count_ordered_within(dat$A_low, low_te_idx)
te_high <- count_ordered_within(dat$A_high, high_te_idx)
tr_low <- count_ordered_within(dat$A_low, low_tr_idx)
tr_high <- count_ordered_within(dat$A_high, high_tr_idx)
mix_low <- count_rectangular(dat$A_low, low_te_idx, low_tr_idx)
mix_high <- count_rectangular(dat$A_high, high_te_idx, high_tr_idx)

counts <- rbind(
  data.frame(pair_class = "temperate_temperate", temperature = "19C", te_low),
  data.frame(pair_class = "temperate_temperate", temperature = "25C", te_high),
  data.frame(pair_class = "tropical_tropical", temperature = "19C", tr_low),
  data.frame(pair_class = "tropical_tropical", temperature = "25C", tr_high),
  data.frame(pair_class = "mixed_temperate_tropical", temperature = "19C", mix_low),
  data.frame(pair_class = "mixed_temperate_tropical", temperature = "25C", mix_high)
)

write.csv(counts, file.path(out_dir, "Table_S2_empirical_pairclass_counts.csv"), row.names = FALSE)
write_counts_tex(counts, file.path(out_dir, "Table_S2_empirical_pairclass_counts.tex"))

# -----------------------------------------------------------------------------
# Size-matched downsampling of tropical species: Supplementary Table S3
# -----------------------------------------------------------------------------

n_te <- length(temperate_names)
n_tr <- length(tropical_names)
if (n_tr < n_te) stop("Tropical pool is smaller than temperate pool; cannot downsample to temperate size.")

subset_mat <- combn(seq_len(n_tr), n_te)
n_sub <- ncol(subset_mat)

subsets <- data.frame(
  subset_id = seq_len(n_sub),
  tropical_prop_19C = NA_real_,
  tropical_prop_25C = NA_real_,
  mixed_prop_19C = NA_real_,
  mixed_prop_25C = NA_real_,
  tropical_25_ge_19 = NA,
  tropical_25_gt_19 = NA,
  mixed_19_gt_25 = NA
)

for (s in seq_len(n_sub)) {
  sel <- subset_mat[, s]

  low_tr_sub <- low_tr_idx[sel]
  high_tr_sub <- high_tr_idx[sel]

  c_tr_low <- count_ordered_within(dat$A_low, low_tr_sub)
  c_tr_high <- count_ordered_within(dat$A_high, high_tr_sub)
  c_mix_low <- count_rectangular(dat$A_low, low_te_idx, low_tr_sub)
  c_mix_high <- count_rectangular(dat$A_high, high_te_idx, high_tr_sub)

  subsets$tropical_prop_19C[s] <- c_tr_low$proportion
  subsets$tropical_prop_25C[s] <- c_tr_high$proportion
  subsets$mixed_prop_19C[s] <- c_mix_low$proportion
  subsets$mixed_prop_25C[s] <- c_mix_high$proportion
  subsets$tropical_25_ge_19[s] <- c_tr_high$proportion >= c_tr_low$proportion
  subsets$tropical_25_gt_19[s] <- c_tr_high$proportion > c_tr_low$proportion
  subsets$mixed_19_gt_25[s] <- c_mix_low$proportion > c_mix_high$proportion
}

summary <- data.frame(
  n_temperate_species = n_te,
  n_tropical_species = n_tr,
  n_tropical_subsets = n_sub,
  pct_mixed_19C_gt_25C = 100 * mean(subsets$mixed_19_gt_25),
  pct_tropical_25C_ge_19C = 100 * mean(subsets$tropical_25_ge_19),
  pct_tropical_25C_gt_19C = 100 * mean(subsets$tropical_25_gt_19)
)

write.csv(subsets, file.path(out_dir, "tropical_downsampling_subsets.csv"), row.names = FALSE)
write.csv(summary, file.path(out_dir, "Table_S3_tropical_downsampling_summary.csv"), row.names = FALSE)
write_downsampling_tex(summary, file.path(out_dir, "Table_S3_tropical_downsampling_summary.tex"))

# Optional diagnostic figure for checking only; not required by the manuscript.
pdf(file.path(out_dir, "tropical_downsampling_diagnostic.pdf"), width = 8, height = 4)
oldpar <- par(no.readonly = TRUE)
par(mfrow = c(1, 2), mar = c(4.2, 4.2, 2.5, 1))
hist(subsets$tropical_prop_25C - subsets$tropical_prop_19C,
     breaks = 30, main = "Tropical-tropical contrast", xlab = "Proportion difference: 25C - 19C",
     ylab = "Number of subsets")
abline(v = 0, lty = 2, lwd = 2)
hist(subsets$mixed_prop_19C - subsets$mixed_prop_25C,
     breaks = 30, main = "Mixed-pair contrast", xlab = "Proportion difference: 19C - 25C",
     ylab = "Number of subsets")
abline(v = 0, lty = 2, lwd = 2)
par(oldpar)
dev.off()

# -----------------------------------------------------------------------------
# Text report
# -----------------------------------------------------------------------------

report <- c(
  "Independent R empirical-table sensitivity analysis",
  "=================================================",
  "",
  paste("Optimal-temperature file:", dat$opt_path),
  paste("Low-temperature matrix:", dat$low_path),
  paste("High-temperature matrix:", dat$high_path),
  "",
  "Coding rule: 2 = coexistence, 0 = non-coexistence, NaN = missing/inapplicable.",
  "Within temperate-temperate and tropical-tropical classes, counts are ordered",
  "off-diagonal outcomes. Mixed-pair counts use the temperate x tropical block.",
  "",
  "Pair-class counts:",
  paste(capture.output(print(counts, row.names = FALSE)), collapse = "\n"),
  "",
  "Downsampling summary:",
  paste(capture.output(print(summary, row.names = FALSE)), collapse = "\n"),
  ""
)
writeLines(report, file.path(out_dir, "empirical_table_sensitivity_report.txt"))

message("Done. Outputs written to: ", out_dir)
print(counts)
print(summary)
