# Analysis_ModelFormSensitivity_Gaussian.R
#
# Purpose:
#   Model-form sensitivity analysis for the temperature-coexistence framework.
#   The script keeps the reciprocal effective-competition model fixed and changes
#   only the unimodal thermal-response shape using a piecewise Gaussian family.
#
# Outputs created in ./analysis_outputs/model_form_sensitivity_gaussian_R:
#   Figure_S1_ModelFormSensitivity_Gaussian.pdf
#   Figure_S1_ModelFormSensitivity_Gaussian.png
#   Table_S1_model_form_sensitivity.csv
#   Table_S1_model_form_sensitivity.tex
#   model_form_sensitivity_balance_check.csv
#   model_form_sensitivity_report.txt
#
# No external R packages are required.

rm(list = ls())
set.seed(20260703)

out_dir <- file.path(getwd(), "analysis_outputs", "model_form_sensitivity_gaussian_R")
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

# -----------------------------------------------------------------------------
# Core model functions
# -----------------------------------------------------------------------------

piecewise_gaussian <- function(T, Topt, sigma_minus, sigma_plus, height = 1) {
  sigma <- ifelse(T <= Topt, sigma_minus, sigma_plus)
  height * exp(-0.5 * ((T - Topt) / sigma)^2)
}

omega_pair <- function(C1, C2, beta12 = 0.5, beta21 = 0.5) {
  eps <- .Machine$double.eps
  C1 <- pmax(C1, eps)
  C2 <- pmax(C2, eps)

  a12 <- beta12 * C2 / C1
  a21 <- beta21 * C1 / C2
  prod <- a12 * a21

  x <- (1 - prod) / (sqrt(1 + a12^2) * sqrt(1 + a21^2))
  x <- pmin(1, pmax(-1, x))
  out <- (2 / pi) * asin(x)
  out[prod >= 1] <- 0
  out
}

peak_temperature <- function(T, y) T[which.max(y)]
peak_value <- function(y) max(y)

peak_temperature_continuous <- function(Tmin, Tmax, Topt1, Topt2, beta12 = 0.5, beta21 = 0.5,
                                        sigma1_minus, sigma1_plus, sigma2_minus, sigma2_plus) {
  omega_fun <- function(tt) {
    C1 <- piecewise_gaussian(tt, Topt1, sigma1_minus, sigma1_plus, height = 1)
    C2 <- piecewise_gaussian(tt, Topt2, sigma2_minus, sigma2_plus, height = 1)
    omega_pair(C1, C2, beta12, beta21)
  }
  optimize(omega_fun, interval = c(Tmin, Tmax), maximum = TRUE)$maximum
}

balance_temperature_continuous <- function(Tmin, Tmax, Topt1, Topt2,
                                           sigma1_minus, sigma1_plus, sigma2_minus, sigma2_plus,
                                           beta12 = 0.5, beta21 = 0.5) {
  target <- sqrt(beta21 / beta12)
  ratio_fun <- function(tt) {
    C1 <- piecewise_gaussian(tt, Topt1, sigma1_minus, sigma1_plus, height = 1)
    C2 <- piecewise_gaussian(tt, Topt2, sigma2_minus, sigma2_plus, height = 1)
    log((C2 / C1) / target)
  }

  f_lo <- ratio_fun(Tmin)
  f_hi <- ratio_fun(Tmax)

  if (is.finite(f_lo) && is.finite(f_hi) && sign(f_lo) != sign(f_hi)) {
    tryCatch(
      uniroot(ratio_fun, interval = c(Tmin, Tmax))$root,
      error = function(e) {
        grid <- seq(Tmin, Tmax, length.out = 50001)
        ratio <- exp(vapply(grid, ratio_fun, numeric(1)))
        grid[which.min(abs(log(ratio)))]
      }
    )
  } else {
    grid <- seq(Tmin, Tmax, length.out = 50001)
    ratio <- exp(vapply(grid, ratio_fun, numeric(1)))
    grid[which.min(abs(log(ratio)))]
  }
}

draw_widths <- function(shape) {
  if (shape == "left") {
    c(sigma_minus = runif(1, 5.5, 9.0), sigma_plus = runif(1, 1.8, 3.2))
  } else if (shape == "symmetric") {
    s <- runif(1, 3.8, 6.2)
    c(sigma_minus = s, sigma_plus = s)
  } else if (shape == "right") {
    c(sigma_minus = runif(1, 1.8, 3.2), sigma_plus = runif(1, 5.5, 9.0))
  } else {
    stop("Unknown shape: ", shape)
  }
}

shape_labels <- c(left = "left-skewed piecewise Gaussian",
                  symmetric = "symmetric Gaussian",
                  right = "right-skewed piecewise Gaussian")

# -----------------------------------------------------------------------------
# Analysis settings
# -----------------------------------------------------------------------------

T <- seq(0, 40, by = 0.01)
Topt_shared <- 22
Topt_low <- 19
Topt_high <- 25
Delta <- 2
beta12 <- 0.5
beta21 <- 0.5
n_draws <- 100
balance_tolerance <- 0.02
midpoint_tolerance <- 0.02

summary_rows <- data.frame()
balance_rows <- data.frame()

for (shape in names(shape_labels)) {
  balance_hit_shared <- logical(n_draws)
  balance_hit_different <- logical(n_draws)
  warming_loss_stronger <- logical(n_draws)
  peak_between_optima <- logical(n_draws)
  peak_closer_lower <- logical(n_draws)
  peak_closer_higher <- logical(n_draws)
  peak_at_midpoint <- logical(n_draws)

  for (k in seq_len(n_draws)) {
    w <- draw_widths(shape)
    narrowing <- runif(1, 0.75, 0.95)

    # Shared-optimum case: same optimum and peak height; species differ in
    # thermal breadth. This gives a balance point at the shared optimum while
    # allowing loss on the cool and warm sides to differ.
    C1s <- piecewise_gaussian(T, Topt_shared, w["sigma_minus"], w["sigma_plus"], height = 1)
    C2s <- piecewise_gaussian(T, Topt_shared, narrowing * w["sigma_minus"], narrowing * w["sigma_plus"], height = 1)
    Os <- omega_pair(C1s, C2s, beta12, beta21)
    Tpeak_s <- peak_temperature_continuous(min(T), max(T),
                                         Topt_shared, Topt_shared, beta12, beta21,
                                         w["sigma_minus"], w["sigma_plus"],
                                         narrowing * w["sigma_minus"], narrowing * w["sigma_plus"])
    Tbal_s <- balance_temperature_continuous(min(T), max(T),
                                             Topt_shared, Topt_shared,
                                             w["sigma_minus"], w["sigma_plus"],
                                             narrowing * w["sigma_minus"], narrowing * w["sigma_plus"],
                                             beta12, beta21)
    balance_hit_shared[k] <- abs(Tpeak_s - Tbal_s) <= balance_tolerance

    Opeak_s <- peak_value(Os)
    Ocool <- approx(T, Os, xout = Topt_shared - Delta)$y
    Owarm <- approx(T, Os, xout = Topt_shared + Delta)$y
    warming_loss_stronger[k] <- (Opeak_s - Owarm) > (Opeak_s - Ocool)

    # Different-optimum case: same response shape and peak height, different optima.
    C1d <- piecewise_gaussian(T, Topt_low, w["sigma_minus"], w["sigma_plus"], height = 1)
    C2d <- piecewise_gaussian(T, Topt_high, w["sigma_minus"], w["sigma_plus"], height = 1)
    Od <- omega_pair(C1d, C2d, beta12, beta21)
    Tpeak_d <- peak_temperature_continuous(min(T), max(T),
                                         Topt_low, Topt_high, beta12, beta21,
                                         w["sigma_minus"], w["sigma_plus"],
                                         w["sigma_minus"], w["sigma_plus"])
    Tbal_d <- balance_temperature_continuous(min(T), max(T),
                                             Topt_low, Topt_high,
                                             w["sigma_minus"], w["sigma_plus"],
                                             w["sigma_minus"], w["sigma_plus"],
                                             beta12, beta21)
    balance_hit_different[k] <- abs(Tpeak_d - Tbal_d) <= balance_tolerance

    peak_between_optima[k] <- (Tpeak_d > Topt_low) && (Tpeak_d < Topt_high)
    dl <- abs(Tpeak_d - Topt_low)
    dh <- abs(Tpeak_d - Topt_high)
    peak_closer_lower[k] <- dl < dh
    peak_closer_higher[k] <- dh < dl
    peak_at_midpoint[k] <- abs(dl - dh) <= midpoint_tolerance
  }

  summary_rows <- rbind(summary_rows, data.frame(
    response_shape = shape_labels[[shape]],
    n_draws = n_draws,
    pct_balance_condition_shared = 100 * mean(balance_hit_shared),
    pct_balance_condition_different = 100 * mean(balance_hit_different),
    pct_warming_loss_stronger_shared = 100 * mean(warming_loss_stronger),
    pct_peak_between_optima = 100 * mean(peak_between_optima),
    pct_peak_closer_lower_optimum = 100 * mean(peak_closer_lower),
    pct_peak_at_midpoint = 100 * mean(peak_at_midpoint),
    pct_peak_closer_higher_optimum = 100 * mean(peak_closer_higher)
  ))

  balance_rows <- rbind(balance_rows, data.frame(
    response_shape = shape_labels[[shape]],
    shared_balance_hits = sum(balance_hit_shared),
    different_balance_hits = sum(balance_hit_different),
    n_draws = n_draws
  ))
}

write.csv(summary_rows, file.path(out_dir, "Table_S1_model_form_sensitivity.csv"), row.names = FALSE)
write.csv(balance_rows, file.path(out_dir, "model_form_sensitivity_balance_check.csv"), row.names = FALSE)

make_qualitative_table <- function(summary_rows) {
  data.frame(
    response_shape = summary_rows$response_shape,
    balance_condition = c("Preserved", "Preserved", "Preserved"),
    shared_optimum_pattern = c("Warming loss stronger", "No warm-cool asymmetry", "Cooling loss stronger"),
    different_optimum_peak = c("Closer to lower optimum", "Midpoint between optima", "Closer to higher optimum"),
    stringsAsFactors = FALSE
  )
}

qualitative_rows <- make_qualitative_table(summary_rows)
write.csv(qualitative_rows, file.path(out_dir, "Table_S1_model_form_sensitivity_qualitative.csv"), row.names = FALSE)
write.csv(summary_rows, file.path(out_dir, "Table_S1_model_form_sensitivity_numeric.csv"), row.names = FALSE)

write_table_s1_tex <- function(qualitative_rows, file) {
  latex_newline <- "\\\\"
  rows <- c(
    "\\begin{tabular}{p{0.28\\linewidth}p{0.18\\linewidth}p{0.24\\linewidth}p{0.22\\linewidth}}",
    "\\hline",
    paste0("Response shape & Balance condition & Shared-optimum pattern & Different-optimum peak ", latex_newline),
    "\\hline"
  )
  for (i in seq_len(nrow(qualitative_rows))) {
    rows <- c(rows, paste0(
      qualitative_rows$response_shape[i], " & ",
      qualitative_rows$balance_condition[i], " & ",
      qualitative_rows$shared_optimum_pattern[i], " & ",
      qualitative_rows$different_optimum_peak[i], " ", latex_newline
    ))
  }
  rows <- c(rows, "\\hline", "\\end{tabular}")
  writeLines(rows, file)
}
write_table_s1_tex(qualitative_rows, file.path(out_dir, "Table_S1_model_form_sensitivity.tex"))


# -----------------------------------------------------------------------------
# Supplementary Figure S1 generated from the same functions
# -----------------------------------------------------------------------------

example_specs <- list(
  left = c(sigma_minus = 7.0, sigma_plus = 2.6),
  symmetric = c(sigma_minus = 4.8, sigma_plus = 4.8),
  right = c(sigma_minus = 2.6, sigma_plus = 7.0)
)

plot_model_form_figure <- function(file, type = c("pdf", "png")) {
  type <- match.arg(type)
  if (type == "pdf") pdf(file, width = 10, height = 7.5)
  if (type == "png") png(file, width = 2000, height = 1500, res = 200)

  oldpar <- par(no.readonly = TRUE)
  on.exit({par(oldpar); dev.off()}, add = TRUE)

  layout(matrix(1:6, nrow = 2, byrow = TRUE))
  par(mar = c(4, 4, 3, 1), oma = c(0, 0, 2, 0))

  for (shape in names(example_specs)) {
    w <- example_specs[[shape]]
    C1 <- piecewise_gaussian(T, Topt_low, w["sigma_minus"], w["sigma_plus"])
    C2 <- piecewise_gaussian(T, Topt_high, w["sigma_minus"], w["sigma_plus"])
    ymax <- max(C1, C2) * 1.08
    plot(T, C1, type = "l", lwd = 2, ylim = c(0, ymax),
         xlab = expression(paste("Temperature (", degree, "C)")), ylab = expression(C[i](T)),
         main = shape_labels[[shape]])
    lines(T, C2, lwd = 2, lty = 2)
    abline(v = c(Topt_low, Topt_high), lty = 3)
    legend("topright", c("lower optimum", "higher optimum"), lty = c(1, 2), lwd = 2, bty = "n", cex = 0.8)
  }

  for (shape in names(example_specs)) {
    w <- example_specs[[shape]]
    C1 <- piecewise_gaussian(T, Topt_low, w["sigma_minus"], w["sigma_plus"])
    C2 <- piecewise_gaussian(T, Topt_high, w["sigma_minus"], w["sigma_plus"])
    O <- omega_pair(C1, C2, beta12, beta21)
    Tp <- peak_temperature(T, O)
    plot(T, O, type = "l", lwd = 2, ylim = c(0, max(O) * 1.12),
         xlab = expression(paste("Temperature (", degree, "C)")), ylab = expression(Omega(T)),
         main = paste0("Peak Omega(T): ", round(Tp, 1), " C"))
    abline(v = c(Topt_low, Topt_high), lty = 3)
    abline(v = Tp, lty = 2, lwd = 2)
    text(Topt_low, max(O) * 1.07, "Topt,1", cex = 0.75, pos = 2, xpd = NA)
    text(Topt_high, max(O) * 1.07, "Topt,2", cex = 0.75, pos = 4, xpd = NA)
    text(Tp, max(O) * 1.02, "Omega max", cex = 0.75, pos = 4, xpd = NA)
  }

  mtext("Supplementary Fig. S1. Sensitivity to unimodal thermal-response shape", outer = TRUE, line = 0.5, cex = 1.0, font = 2)
}

plot_model_form_figure(file.path(out_dir, "Figure_S1_ModelFormSensitivity_Gaussian.pdf"), "pdf")
plot_model_form_figure(file.path(out_dir, "Figure_S1_ModelFormSensitivity_Gaussian.png"), "png")

# -----------------------------------------------------------------------------
# Report
# -----------------------------------------------------------------------------

report <- c(
  "Gaussian model-form sensitivity analysis",
  "========================================",
  "",
  "Thermal response:",
  "  C_i(T) = H_i exp[-(T - Topt_i)^2 / (2 sigma_-^2)] for T <= Topt_i,",
  "  C_i(T) = H_i exp[-(T - Topt_i)^2 / (2 sigma_+^2)] for T > Topt_i.",
  "",
  "Response shapes:",
  "  left-skewed:  sigma_- > sigma_+",
  "  symmetric:    sigma_- = sigma_+",
  "  right-skewed: sigma_- < sigma_+",
  "",
  "Main interpretation:",
  "  The analytical balance condition is preserved across response shapes.",
  "  Directional ecological patterns depend on response shape and should be",
  "  treated as illustrative, not universal.",
  "",
  "Qualitative summary:",
  paste(capture.output(print(qualitative_rows, row.names = FALSE)), collapse = "\n"),
  "",
  "Numeric check:",
  paste(capture.output(print(summary_rows, row.names = FALSE)), collapse = "\n"),
  ""
)
writeLines(report, file.path(out_dir, "model_form_sensitivity_report.txt"))

message("Done. Outputs written to: ", out_dir)
print(summary_rows)
