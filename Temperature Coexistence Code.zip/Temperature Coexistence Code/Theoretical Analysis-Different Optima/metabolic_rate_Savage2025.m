function results = metabolic_rate_Savage2025(T, T_max, T_min, T_opt, beta)
% This function gives metabolic rates following the model given by
% Cruz-Loya M., Mordecai E.A., and Savage V.M.

alpha=(T_opt-T_min)/(T_max-T_min);

tem1=(T-T_min)/alpha;
tem1=tem1^alpha;

tem2=(T_max-T)/(1-alpha);
tem2=tem2^(1-alpha);

tem3=1/(T_max-T_min);

tem4=alpha*(1-alpha)/(beta^2);

tem=tem1*tem2*tem3;
tem=tem^(tem4);

results=tem;

end