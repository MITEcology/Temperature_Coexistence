% This script generates figures for coexistence probability for two
% competiting species sharing the same thermal optima and corresponding
% consumption rates

clear; clc;
close all;

S=2; num_sample=10; N=10000;

a0=0.1;

M_r=0.8;
M(1)=1; M(2)=M_r*M(1);

r_th=1e-10;

r_max(1)=1; r_max(2)=1;

beta0=0.07;
beta(1)=beta0*M(1)^(3/4); beta(2)=beta0*M(2)^(3/4);

T_min=0+273.15; T_max=30+273.15;

T_opt(1)=19+273.15; T_opt(2)=19+273.15;

T_start=T_min; T_step=0.01; T_end=T_max;

A=ones(S,S);

flag_T=1;
for T=T_start:T_step:T_end

    tem1=r_max(1)*metabolic_rate_Savage2025(T, T_max, T_min, T_opt(1), beta(1));
    if(abs(tem1)<r_th)

        tem1=0;

    end

    C1(flag_T)=tem1*M(1)^(3/4);

    tem2=r_max(2)*metabolic_rate_Savage2025(T, T_max, T_min, T_opt(2), beta(2));
    if(abs(tem2)<r_th)

        tem2=0;

    end

    C2(flag_T)=tem2*M(2)^(3/4);

    A(1,2)=a0*(C2(flag_T)/C1(flag_T));
    A(2,1)=a0*(C1(flag_T)/C2(flag_T));

    K1=0:0.01:2;

    K2_min=(A(2,1)/A(1,1))*K1;
    K2_max=(A(2,2)/A(1,2))*K1;

    tem_size1=A(1,1)*A(2,2)-A(1,2)*A(2,1);

    tem_size2=A(1,1)^2+A(2,1)^2;
    tem_size2=sqrt(tem_size2);

    tem_size3=A(1,2)^2+A(2,2)^2;
    tem_size3=sqrt(tem_size3);

    tem_size4=tem_size1/(tem_size2*tem_size3);

    g1(flag_T)=tem1;
    g2(flag_T)=tem2;

    FD_Size(flag_T)=(2/pi)*asin(tem_size4);

    T_plot(flag_T)=T;

    flag_T=flag_T+1;

end

T_plot=T_plot-273.15;

FD_Size_clean=FD_Size(~isnan(FD_Size));
isequal=all(FD_Size_clean==FD_Size_clean(1));

max_FDSize_coor=1;
if(isequal==0)
    max_FDSize_coor=find(FD_Size==max(FD_Size));
    T_plot(max_FDSize_coor)
end

y_plot_opt=0:0.01:2;
T_plot_opt1=T_opt(1)*ones(length(y_plot_opt),1)-273.15;
T_plot_opt2=T_opt(2)*ones(length(y_plot_opt),1)-273.15;

color=colormap(lines(4));

figure(1);
set(gcf,'unit','centimeters','position',[5,5,6,6*(3/4)]);

p1=plot(T_plot,FD_Size,'LineWidth',0.75,'Color',color(1,:));
hold on;
s1=scatter(T_plot(max_FDSize_coor),FD_Size(max_FDSize_coor),10,'filled','MarkerFaceColor',color(2,:));
hold on;
p21=plot(T_plot_opt1,y_plot_opt,'--','LineWidth',0.75,'Color',color(3,:));
hold on;
p22=plot(T_plot_opt2,y_plot_opt,'--','LineWidth',0.75,'Color',color(4,:));

axis([min(T_min)-273.15,max(T_max)-273.15+1,0,1.1]);

%l1=legend([p1,s1,p21,p22],{'Feasibility domain size','Optimum (Simu.)','Optimum (Species 1)','Optimum (Species 2)'});
%set(l1,'Location','best','Box','off');

xlabel('Temperature,T');
ylabel('Feasibility domain size');

set(gca,'fontsize',8);

figure(2);
set(gcf,'unit','centimeters','position',[5,5,6,6*(3/4)]);

pc1=plot(T_plot,C1,'LineWidth',0.75);
hold on;
pc2=plot(T_plot,C2,'LineWidth',0.75);

axis([min(T_min)-273.15,max(T_max)-273.15+1, 0, 1.1]);

xlabel('Temperature,T');
ylabel('Rate');

set(gca,'fontsize',8);

%{
figure(3);

pc1=plot(T_plot,g1,'LineWidth',3);
hold on;
pc2=plot(T_plot,g2,'LineWidth',3);
l1=legend([pc1,pc2],{'\beta=0.05','\beta=0.1'});
set(l1,'location','best','box','off');
xlabel('Temperature,T');
ylabel('Rate');

set(gca,'fontsize',20);

T=table(T_plot', g1', g2', 'VariableNames', {'Time', 'Rate1', 'Rate2'});
writetable(T, 'Temperature_response_data_DiffOpt.xlsx');
%}