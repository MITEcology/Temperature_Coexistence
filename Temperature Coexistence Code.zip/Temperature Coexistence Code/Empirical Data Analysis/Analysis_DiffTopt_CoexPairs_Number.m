% This script generates figures for coexistence outcomes of Drosophila
% species with different thermal optimas

clear; clc;
close all;

data_label{1}='FruitFly_Coexistence_LowT_Thick.mat';
data_label{2}='FruitFly_Coexistence_HighT_Thick.mat';

T_opt1=19; T_opt2=25;

for flag_data=1:2

    data_coexistence{flag_data}=load(data_label{flag_data});
    data_DryWt=load('FruitFly_DryWt.mat');
    data_opttemperature=load('FruitFly_OptimalTemperature.mat');

    coexistence_matrix{flag_data}=data_coexistence{flag_data}.A;
    coexistence_name{flag_data}=data_coexistence{flag_data}.Name;

    drywt_weight=data_DryWt.DryWt;
    drywt_name=data_DryWt.Name;

    opttem_tem=data_opttemperature.Temperature;
    opttem_name=data_opttemperature.Name;

    species_name=opttem_name;


    tem_label=data_label{flag_data}(22:25);
    if(strcmp(tem_label,'High')==1)

        Te=25+273.13;

    end

    if(strcmp(tem_label,'LowT')==1)

        Te=19+273.13;

    end

    total_species_num=max(size(species_name));
    data_species_num=max(size(coexistence_name{flag_data}));

    flag_species_19=1;
    flag_species_25=1;
    for i=1:total_species_num

        if(opttem_tem(i)==T_opt1)

            tem_name1=species_name{i};
            opttem19_name{flag_species_19}=tem_name1;

            flag_species_19=flag_species_19+1;

        end

        if(opttem_tem(i)==T_opt2)

            tem_name1=species_name{i};
            opttem25_name{flag_species_25}=tem_name1;

            flag_species_25=flag_species_25+1;

        end

    end

    species_name_reorder=[opttem19_name,opttem25_name];

    analyze_species_num=max(size(species_name_reorder));

    coexistence_matrix_extract{flag_data}=zeros(analyze_species_num,analyze_species_num);

    for i=1:analyze_species_num

        name1=species_name_reorder{i};

        for m=1:data_species_num

            if(strcmp(coexistence_name{flag_data}{m},name1)==1)

                coex_coor1=m;

            end

        end

        for j=i+1:analyze_species_num

            name2=species_name_reorder{j};

            for n=1:data_species_num

                if(strcmp(coexistence_name{flag_data}{n},name2)==1)

                    coex_coor2=n;

                end

            end

            coex_flag1=coexistence_matrix{flag_data}(coex_coor1,coex_coor2);
            coex_flag2=coexistence_matrix{flag_data}(coex_coor2,coex_coor1);

            if(coex_flag1~=0)

                coex_flag1=1;

            end

            if(coex_flag2~=0)

                coex_flag2=1;

            end

            coexistence_matrix_extract{flag_data}(i,j)=coex_flag1;
            coexistence_matrix_extract{flag_data}(j,i)=coex_flag2;

        end

    end

    num_species_19=max(size(opttem19_name));
    num_species_25=max(size(opttem25_name));

    coexistence_matrix_diff{flag_data}=coexistence_matrix_extract{flag_data}(1:num_species_19,num_species_19+1:end);

    figure(flag_data);
    set(gcf,'unit','centimeters','position',[5,5,6,6*(3/4)]);

    h{flag_data}=heatmap(coexistence_matrix_diff{flag_data});

    h{flag_data}.CellLabelColor = 'none';
    h{flag_data}.ColorbarVisible = 'off';

    nCol_x = size(coexistence_matrix_diff{flag_data}, 2);
    lbl_x  = strings(1, nCol_x);     % 先全部空
    lbl_x([1,5,10,15]) = ["11","15","20","25"];  % 只在 1、5、10 处显示
    h{flag_data}.XDisplayLabels = lbl_x;

    nCol_y = size(coexistence_matrix_diff{flag_data}, 1);
    lbl_y  = strings(1, nCol_y);     % 先全部空
    lbl_y([1,5,10]) = ["1","5","10"];  % 只在 1、5、10 处显示
    h{flag_data}.YDisplayLabels = lbl_y;

    s  = struct(h{flag_data});        % 取到底层 axes
    ax = s.Axes;
    ax.XAxis.TickLabelRotation = 0;   % 设为不旋转

    xlabel('Species number');
    ylabel('Species number');

    %title(['Environmental temperature=',num2str(Te-273.13),'^{\circ}C']);

    set(gca,'fontsize',8);

    num_coex_pair(flag_data)=sum(sum(coexistence_matrix_diff{flag_data}));

end

num_coex_pair=num_coex_pair/150;

figure(3);
set(gcf,'unit','centimeters','position',[5,5,6,6*(3/4)]);

bar(num_coex_pair);

axis([0 3 0 1.1]);

xticks([1 2]);
xticklabels({'19','25'});

ylabel('Counts');
xlabel('Temperature');

set(gca,'fontsize',8);