% This script generates figures for coexistence outcomes of Drosophila
% species sharing the same thermal optima of 19 Celsius degree

clear; clc;
close all;

T_opt=19;

data_label{1}='FruitFly_Coexistence_LowT_Thick.mat';
data_label{2}='FruitFly_Coexistence_HighT_Thick.mat';

for flag_data=1:2

    data_coexistence{flag_data}=load(data_label{flag_data});
    data_DryWt=load('FruitFly_DryWt.mat');
    data_opttemperature=load('FruitFly_OptimalTemperature.mat');

    coexistence_matrix{flag_data}=data_coexistence{flag_data}.A;
    coexistence_name{flag_data}=data_coexistence{flag_data}.Name;

    drywt_weight=data_DryWt.DryWt;
    drywt_name=data_DryWt.Name;

    opttem_tem=data_opttemperature.Temperature;
    opttem_name=data_opttemperature.Name;

    species_name=opttem_name;

    tem_label=data_label{flag_data}(22:25);
    if(strcmp(tem_label,'High')==1)

        Te=25+273.13;

    end

    if(strcmp(tem_label,'LowT')==1)

        Te=19+273.13;

    end

    total_species_num=max(size(species_name));
    data_species_num=max(size(coexistence_name{flag_data}));

    flag_species=1;
    for i=1:total_species_num

        if(opttem_tem(i)==T_opt)

            tem_name1=species_name{i};

            for k=1:data_species_num

                if(strcmp(coexistence_name{flag_data}{k},tem_name1)==1)

                    species_name_extract{flag_data}{flag_species}=tem_name1;

                    flag_species=flag_species+1;

                end

            end

        end

    end
    analyze_species_num=max(size(species_name_extract{flag_data}));

    coexistence_matrix_extract{flag_data}=zeros(analyze_species_num,analyze_species_num);
    for i=1:analyze_species_num

        name1=species_name_extract{flag_data}{i};

        for m=1:data_species_num

            if(strcmp(coexistence_name{flag_data}{m},name1)==1)

                coex_coor1=m;

            end

        end

        for j=i+1:analyze_species_num

            name2=species_name_extract{flag_data}{j};

            for n=1:data_species_num

                if(strcmp(coexistence_name{flag_data}{n},name2)==1)

                    coex_coor2=n;

                end

            end

            coex_flag1=coexistence_matrix{flag_data}(coex_coor1,coex_coor2);
            coex_flag2=coexistence_matrix{flag_data}(coex_coor2,coex_coor1);

            if(coex_flag1~=0)

                coex_flag1=1;

            end

            if(coex_flag2~=0)

                coex_flag2=1;

            end

            coexistence_matrix_extract{flag_data}(i,j)=coex_flag1;
            coexistence_matrix_extract{flag_data}(j,i)=coex_flag2;

        end

    end

    figure(flag_data);
    set(gcf,'unit','centimeters','position',[5,5,6,6*(3/4)]);

    h{flag_data}=heatmap(coexistence_matrix_extract{flag_data});

    h{flag_data}.CellLabelColor = 'none';
    h{flag_data}.ColorbarVisible = 'off';

    nCol = size(coexistence_matrix_extract{flag_data}, 2);
    lbl  = strings(1, nCol);     % 先全部空
    lbl([1,5,10]) = ["1","5","10"];  % 只在 1、5、10 处显示
    h{flag_data}.XDisplayLabels = lbl;
    h{flag_data}.YDisplayLabels = lbl;

    s  = struct(h{flag_data});        % 取到底层 axes
    ax = s.Axes;
    ax.XAxis.TickLabelRotation = 0;   % 设为不旋转

    xlabel('Species number');
    ylabel('Species number');

    %title(['Environmental temperature=',num2str(Te-273.13),'^{\circ}C']);

    set(gca,'fontsize',8);

    num_coex_pair(flag_data)=sum(sum(coexistence_matrix_extract{flag_data}))/2;

end

overlap_pair_num=0;
for i=1:analyze_species_num

    for j=i+1:analyze_species_num

        if(coexistence_matrix_extract{1}(i,j)==1)&&(coexistence_matrix_extract{2}(i,j)==1)

            overlap_pair_num=overlap_pair_num+1;

        end

    end

end

coexistence_pair_num=[num_coex_pair]/45;

figure(flag_data+1);
set(gcf,'unit','centimeters','position',[5,5,6,6*(3/4)]);

bar(coexistence_pair_num);

axis([0 3 0 1.1]);

xticks([1 2]);
xticklabels({'19{\circ}C','25{\circ}C'});

ylabel('Counts');
xlabel('Temperature');

set(gca,'fontsize',8);